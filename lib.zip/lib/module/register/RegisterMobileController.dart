import 'package:get/get.dart';

class RegisterMobileController extends GetxController{


}