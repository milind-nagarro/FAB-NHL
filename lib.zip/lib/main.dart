import 'package:fab_nhl/locale/AppText.dart';
import 'package:fab_nhl/route/AppPages.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'module/welcome/Welcome.dart';

void main() {
  runApp(GetMaterialApp(
    // home: Welcome(),
    translations: AppText(),
    locale: const Locale('en_US'),
    // translations will be displayed in that locale
    fallbackLocale: const Locale('en_US'),
    getPages: AppPages.routes,
    initialRoute: AppPages.INITIAL,
  ));
}
