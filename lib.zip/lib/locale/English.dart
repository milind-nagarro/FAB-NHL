const Map<String, String> labels = {
  'login': 'Login',
  'register': 'Register',
  'enter_mobile': 'Enter your mobile number',
};