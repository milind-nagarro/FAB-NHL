const Map<String, String> labels = {
'login': 'تسجيل الدخول',
'register': 'يسجل',
'enter_mobile': 'ar Enter your mobile number',
};